### Common Functions ###


## Libraries
suppressMessages(library(pROC))
suppressMessages(library(e1071))



##########################
##### File Operation #####



#' K-Fold Cross Validation
#'
#' Creating a list containing the sample index of each fold in a k-fold CV.
#'
#' @param Labels sample labels, factor
#' @param folds fold in cv, int
#' @param s random seed, int
#'
#' @return a list of sample index
#' @export
#'
#' @examples
#' Labels <- factor(c(0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1))
#' SampleFolds <- CrossValidationSampling(Labels, 5, 1)
CrossValidationSampling <- function(Labels, folds, s)
{
  set.seed(s)
  indexList <- list()

  Labels = factor(Labels) # transfer to Labels
  DiffLabels = levels(Labels) # different class labels

  groupIDs <- 1:folds
  start <- 1
  for (i in 1:length(DiffLabels))
  {
    indexs <- which(Labels==DiffLabels[i]) # sample index in current class
    ClassSamples <- sample(indexs, length(indexs))  # randomly shuffle
    sampleIDs <- rep(1:folds, ceiling(length(indexs)/folds) + 1)[(start):(length(indexs)+start-1)] # groups
    start <- sampleIDs[length(sampleIDs)] %% folds + 1

    currentList <- lapply(groupIDs, function(ID) ClassSamples[sampleIDs==ID])
    if(!length(indexList)) # first class
    {
      indexList <- currentList
    }else{
      indexList <- lapply(groupIDs, function(ID) append(indexList[[ID]], currentList[[ID]]))
    }
  }

  return(indexList)
}



#' Read Data Matrix
#'
#' Reading the data from a csv file. In the data file, the first row indicates the sample labels, the first column indicates feature names.
#'
#' @param fileName csv file name, string
#'
#' @return a list of data (data_matrix, features, labels)
#' @export
#'
#' @importFrom utils read.csv
#'
#' @examples "Omit"
DataReader <- function(fileName)
{
  originData <- utils::read.csv(fileName, header=F)
  originData <- t(originData) # sample * feature

  # Labels (factor, characters)
  FirstCol <- originData[,1]
  Labels <- factor(as.integer(FirstCol[-1]))
  SampleNumber <- length(Labels)

  # Features (vector, string)
  FirstRow <- originData[1,]
  Features <- as.character(FirstRow[-1])
  FeatureNumber <- length(Features)

  # Datas : Samples * Features
  Datas <- as.numeric(originData[-1,-1])
  Datas <- matrix(Datas, nrow=SampleNumber)
  colnames(Datas) <- Features

  print("------------------------")
  print(fileName)
  print(paste("Sample Number:", SampleNumber))
  print(paste("Feature Number:", FeatureNumber))
  print("------------------------")

  DataList <- list(Datas, Features, Labels)
  return(DataList)
}



#' Get File Title Prefix
#'
#' @param fileName file name, string
#'
#' @return data file prefix, string
#' @export
#'
#' @examples
#' file_name <- "Files/data.csv"
#' file_prefix <- GetFilePrefix(file_name)
GetFilePrefix <- function(fileName)
{
  prefix <- unlist(strsplit(fileName, "/", fixed = TRUE))[2]
  prefix <- unlist(strsplit(prefix, ".", fixed = TRUE))[1]
  return(prefix)
}



#' Get Sim Matrix
#'
#' Reading the functional similarity matrix from a txt file.
#'
#' @param file_background file of miRNA similarity matrix, string, txt file
#'
#' @return a list of sim matrix (features, data matrix)
#' @export
#'
#' @importFrom utils read.table
#'
#' @examples "Omit"
GetSimMatrixDatabase <- function(file_background)
{
  # data frame
  df_background <- utils::read.table(file_background, sep = " ", header = TRUE)
  background_features <- colnames(df_background)  # features
  background_sim_matrix <- matrix(as.numeric(unlist(df_background)), ncol=length(background_features))  # data.frame to matrix

  background_list <- list(background_features=background_features, background_sim_matrix=background_sim_matrix)
  print(paste("Get", file_background))

  return(background_list)
}



#' Save Result Info
#'
#' Saving the basic info of the experiment.
#'
#' @param method_type method name, string
#' @param file_prefix file prefix, string
#' @param Times Times in cv, int
#' @param Folds Folds in cv, int
#' @param exe_time exe time, float
#' @param end_time end time, string
#'
#' @return None (File Saved)
#' @export
#'
#' @examples "Omit"
SaveResultSummary <- function(method_type, file_prefix, Times, Folds, exe_time, end_time)
{
  # create file
  file_path <- paste0(file_prefix, "_summary.txt")
  if(file_path %in% dir()){
    is_deleted <- file.remove(file_path)
  }

  # print records
  cat("--------------------------", "\n", file = file_path, append = T)
  cat(method_type, "\n", file = file_path, append = T)
  cat(file_prefix, "\n", file = file_path, append = T)
  cat('cv', Times, Folds, "\n", file = file_path, append = T)
  cat("--------------------------", "\n", file = file_path, append = T)
  cat("Time:", exe_time, "mins", "\n", file = file_path, append = T)
  cat(end_time, "\n", file = file_path, append = T)

  print("Summary Saved.")
}



#' Initialize a List of Matrix
#'
#' @param num_matrix number of matrix
#' @param list_num_row list of row number
#' @param list_num_col list of col number
#'
#' @return a list of matrix
#' @export
#'
#' @examples "Omit"
#' list_matrix <- ResultMatrixInit(1, 10, 10)
ResultMatrixInit <- function(num_matrix, list_num_row, list_num_col)
{
  list_matrix <- list()
  for(i in 1:num_matrix){
    list_matrix[[i]] <- matrix(0, nrow = list_num_row[i], ncol = list_num_col[i])
  }

  return(list_matrix)
}



#' Save A Result Matrix
#'
#' @param list_matrix list of matrix
#' @param list_file_name vector of filenames, for each matrix in list_matrix
#'
#' @return None (File Saved)
#' @export
#'
#' @importFrom utils write.csv
#'
#' @examples "Omit"
ResultMatrixSave <- function(list_matrix, list_file_name)
{
  num_matrix <- length(list_matrix)
  for(i in 1:num_matrix){
    utils::write.csv(list_matrix[[i]], file=list_file_name[i], row.names=F)
  }
  print("Saved")
  print(list_file_name)
}



#' Transform Vector to String
#'
#' Linking the elements with '_' and return a string.
#'
#' @param vec_values a vector of values
#'
#' @return a string
#' @export
#'
#' @examples
#' Vector2string(1:5)
Vector2string <- function(vec_values)
{
  str_values <- ""
  for(i in 1:length(vec_values)){
    str_values <- paste(str_values, vec_values[i], sep = "_")
  }

  return(str_values)
}


###########################
##### Data Processing #####



#' UV scaling
#'
#' Performing UV scaling on training samples and test samples. Using the 'mean' and 'std' from training samples.
#'
#' @param TrainDatas training data, matrix, sample*feature
#' @param TestDatas test data, matrix, sample*feature
#'
#' @return list of matrix (TrainDatas_scaled, TestDatas_scaled)
#' @export
#'
#' @examples "Omit"
UVScaling <- function(TrainDatas, TestDatas)
{
  TrainDatas_scaled <- scale(TrainDatas, center=T, scale=T)
  train_mean <- attr(TrainDatas_scaled, 'scaled:center')
  train_sd <- attr(TrainDatas_scaled, 'scaled:scale')
  TestDatas_scaled <- scale(TestDatas, train_mean, train_sd)

  ScaledDatas <- list(TrainDatas_scaled, TestDatas_scaled)
  print("UV scaling")

  return(ScaledDatas)
}



#' Zero Value Filling
#'
#' @param TrainDatas training data, matrix, sample*feature
#'
#' @return a matrix of transformed data
#' @export
#'
#' @examples "Omit"
ZeroFill <- function(TrainDatas)
{
  TrainDatas_filled <- TrainDatas
  if(0 %in% TrainDatas){
    TrainDatas_filled[which(TrainDatas == 0)] <- 0.000001
  }

  return(TrainDatas_filled)
}



#' Vector Normalization
#'
#' Min-Max normalization for a vector.
#'
#' @param origin_vector numeric vector, vector
#' @param norm_type norm type, string (Only "max_min")
#'
#' @return a normalized vector
#' @export
#'
#' @examples
#' normalized_vector <- VectorNormalization(1:20, "max_min")
VectorNormalization <- function(origin_vector, norm_type)
{
  normalized_vector <- c()
  if(norm_type == "max_min"){
    normalized_vector <- (origin_vector - min(origin_vector)) / (max(origin_vector) - min(origin_vector))
  }

  print(paste("Vector Normalization", norm_type))
  return(normalized_vector)
}



################################
##### Evaluation Functions #####


#' Sensitivity, Specificity in ROC
#'
#' Calculating the sensitivity, specificity based on a pROC::roc() object.
#'
#' @param rocModel a model from pROC::roc()
#'
#' @return a list of results (sensitivity, specificity)
#' @export
#'
#' @examples "Omit"
SenSpeForROC <- function(rocModel)
{
  sen_values <- rocModel$sensitivities
  spe_values <- rocModel$specificities

  # index
  rocModel_sum <- sen_values + spe_values
  rocModel_diff <- abs(sen_values - spe_values)
  index_max <- which(rocModel_sum == max(rocModel_sum))  # which.max

  # check for max values
  if(length(index_max) > 1){
    index_max <- index_max[which.min(rocModel_diff[index_max])]
  }
  SenSpeResults <- list(sen_values[index_max], spe_values[index_max])

  return(SenSpeResults)
}


#' Evaluation by Inner Cross Validation
#'
#' @param data_matrix data matrix, matrix
#' @param data_labels sample labels, factor
#' @param classifier classifier, return the predict_labels and predict_prob
#' @param seed random seed, int
#' @param inner_folds inner folds, default 5
#'
#' @return list of results (mean_performance, predict_prob_all)
#' @export
#'
#' @importFrom pROC roc
#'
#' @examples "Omit"
CrossValidationEvaluation <- function(data_matrix, data_labels, classifier, seed=0, inner_folds=5)
{
  eva_value_list <- rep(0, inner_folds)  # evaluation values
  predict_prob_all <- rep(0, length(data_labels))  # prediction of all samples

  innerSampleFolds <- CrossValidationSampling(data_labels, inner_folds, seed)
  for(i in 1:inner_folds)
  {
    inner_data_train <- matrix(data_matrix[-innerSampleFolds[[i]], ], ncol=ncol(data_matrix))  # train data
    inner_data_test <- matrix(data_matrix[innerSampleFolds[[i]], ], ncol=ncol(data_matrix))  # test data
    inner_labels_train <- data_labels[-innerSampleFolds[[i]]]  # train labels
    inner_labels_test <- data_labels[innerSampleFolds[[i]]]  # test labels

    predict_prob <- classifier(inner_data_train, inner_labels_train, inner_data_test)[[2]]
    predict_prob_all[innerSampleFolds[[i]]] <- predict_prob

    eva_value_list[i] <- pROC::roc(inner_labels_test, predict_prob, quiet=TRUE)$auc
  }

  return(list(eva_value = mean(eva_value_list),
              predict_prob_cv = predict_prob_all))
}



#' SVM Classifier
#'
#' SVM by e1071, linear kernel, binary classification.
#' Return the results of test samples.
#'
#' @param data_train train data, matrix
#' @param labels_train sample labels, factor
#' @param data_test test data, matrix
#'
#' @return list of results (predict_labels, predict_prob)
#' @export
#'
#' @importFrom e1071 svm
#' @importFrom stats predict
#'
#' @examples "Omit"
SVMClassifier <- function(data_train, labels_train, data_test)
{
  svm_model <- e1071::svm(x=data_train, y=labels_train, kernel='linear', cost=1.0, scale=FALSE, probability=TRUE)
  predict_results <- stats::predict(svm_model, newdata=data_test, probability=TRUE)

  # prediction
  predict_labels <- predict_results

  predict_prob_matrix <- attr(predict_results, "probabilities")
  class_names <- colnames(predict_prob_matrix)
  class_labels <- levels(labels_train)
  index_case <- which(class_names == class_labels[length(class_labels)])
  predict_prob <- predict_prob_matrix[, index_case]

  return(list(predict_labels, predict_prob))
}



#' SVM Classifier (Multi-class)
#'
#' SVM by e1071, linear kernel, multi-class classification.
#' Return the results of test samples.
#'
#' @param data_train train data, matrix
#' @param labels_train sample labels, factor
#' @param data_test test data, matrix
#'
#' @return list of results (predict_labels, predict_prob)
#' @export
#'
#' @importFrom e1071 svm
#' @importFrom stats predict
#'
#' @examples "Omit"
SVMClassifier_multiclass <- function(data_train, labels_train, data_test)
{
  svm_model <- e1071::svm(x=data_train, y=labels_train, kernel='linear', cost=1.0, scale=FALSE, probability=TRUE)
  predict_results <- stats::predict(svm_model, newdata=data_test, probability=TRUE)

  # prediction
  predict_labels <- predict_results

  predict_prob_matrix <- attr(predict_results, "probabilities")
  class_names <- colnames(predict_prob_matrix)
  class_labels <- levels(labels_train)
  index_list<- unlist(lapply(1:length(class_labels), function(x){which(class_names == class_labels[x])} ))
  predict_prob <- predict_prob_matrix[, index_list]  # sorted matrix

  return(list(predict_labels, predict_prob))
}



#'  Select the Best Module by CV
#'
#' @param ModuleList 'Module' list, list of list
#' @param data_labels sample labels, factor
#' @param classifier classifier, defined function
#'
#' @return list of results (max_index, max_performance)
#' @export
#'
#' @examples "Omit"
ModuleListEvaluation <- function(ModuleList, data_labels, classifier)
{
  num_module <- length(ModuleList[["node_index"]])
  print("Module List Evaluation")
  print(paste(num_module, "modules"))

  max_index <- 1
  max_value <- 0
  for(p in 1:num_module)
  {
    module_performance <- CrossValidationEvaluation(ModuleList[["node_data_train"]][[p]],
                                                    data_labels,
                                                    classifier,
                                                    seed=0,
                                                    inner_folds=5)[[1]]

    if(module_performance > max_value){
      max_value <- module_performance
      max_index <- p
    }
    print(paste("Eva", p, module_performance, "max", max_index, max_value))
  }

  print(paste("Select", max_index, "by", max_value))
  return(list(max_index = max_index,
              max_value = max_value))
}



#' Weights for Modules by CV
#'
#' Module weights by evaluating the mean performance in an inner 5-fold cross validation.
#'
#' @param ModuleResults "Module" list, list of list
#' @param data_labels sample labels, factor
#' @param classifier classifier, function
#'
#' @return a vector of weights
#' @export
#'
#' @examples "Omit"
ModuleWeightListCV <- function(ModuleResults, data_labels, classifier)
{
  # basic info
  num_modules <- length(ModuleResults[["node_index"]])

  # weights in cross validation
  weights_list <- rep(0, num_modules)
  for(i in 1:num_modules)
  {
    module_data <- ModuleResults[["node_data_train"]][[i]]
    weights_list[i] <- CrossValidationEvaluation(module_data, data_labels, classifier, seed=0, inner_folds=5)[[1]]
  }

  return(weights_list)
}



#' Weighted Average Prediction
#'
#' Integrating the predictions by Weighted averaging.
#'
#' @param ModuleProbs probs of modules, matrix, sample*module
#' @param norm_type weight normalization type, string, 'softmax' only
#' @param module_weights weights for each module, vector
#'
#' @return a vector of prediction probs
#' @export
#'
#' @examples "Omit"
WeightedAverageModulePrediction <- function(ModuleProbs, norm_type, module_weights)
{
  # module weights
  module_weights_norm <- module_weights

  if(norm_type == "softmax"){
    module_weights_norm <- exp(module_weights) / sum(exp(module_weights))

  }
  module_weights_matrix <- matrix(rep(module_weights_norm, each=nrow(ModuleProbs)), nrow=nrow(ModuleProbs))

  # weighted average prob
  weighted_average_probs <- apply(ModuleProbs * module_weights_matrix, 1, sum)

  return(weighted_average_probs)
}



#' Make New Dir
#'
#' Creating a folder for each data file in folder "Results".
#'
#' @param target_dir path of workspace, string
#' @param file_prefix file prefix, string
#'
#' @return full path of dir
#' @export
#'
#' @examples "Omit"
MakeNewDir <- function(target_dir, file_prefix)
{
  # "Results"
  dir_results <- paste0(getwd(), '/Results')
  if(!dir.exists(dir_results)){
    dir.create(dir_results)
  }
  # delete old
  full_path <- paste0(target_dir, '/', file_prefix)
  if(dir.exists(full_path)){
    unlink(full_path, recursive = T)
  }
  # make new
  dir.create(full_path)
  print(paste(full_path, "Made."))

  return(full_path)
}


