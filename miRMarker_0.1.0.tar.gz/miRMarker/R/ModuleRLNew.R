### Module from Reinforcement Learning ###


## Libraries
suppressMessages(library(igraph))
suppressMessages(library(pROC))
# suppressMessages(source("R/Functions_miRNA.R"))



##################################
##### Reinforcement Learning #####



#' Module Identification by Reinforcement Learning
#'
#' @param net_matrix adjacency matrix, matrix
#' @param data_matrix data matrix, matrix
#' @param data_labels sample labels, factor
#' @param agent_list agent list, vector
#' @param classifier classifier, FUN
#' @param episodes episode number, int
#' @param alpha_value alpha, learning rate, float
#' @param gamma_value gamma, reward delay, float
#'
#' @return list of modules
#' @export
#'
#' @examples "Omit"
ModuleIdentifiedByRL <- function(net_matrix, data_matrix, data_labels, agent_list, classifier, episodes, alpha_value, gamma_value)
{
  # basic info
  num_node <- ncol(net_matrix)
  num_agent <- length(agent_list)
  set.seed(77)

  # learning rate delay
  epsilon_f <- 1e-5
  d_value <- (epsilon_f)^(1/episodes)

  # multi agents
  multi_module_list <- list()
  for(k in 1:num_agent)
  {
    print(paste("agent,", k, "/", num_agent, "-", agent_list[k]))

    # q table init
    q_table <- matrix(0, ncol=num_node, nrow=num_node)

    # episode loop
    p_bar <- utils::txtProgressBar(min=0, max=episodes, style=3)
    for(t in 1:episodes)
    {
      # node set
      nodes_selected <- c(agent_list[k])

      # epsilon rate
      epsilon <- d_value^t  # epsilon (convex function)

      # search
      while(TRUE)
      {
        # action
        state_node <- nodes_selected[length(nodes_selected)]  # state node (last node in set)
        action_node <- EpsilonGreedyModified(nodes_selected, net_matrix, q_table, epsilon)  # action node
        if(action_node == -1){
          # print("-- end at no neighbor")
          break
        }
        nodes_selected <- c(nodes_selected, action_node)

        # module data (for reward)
        module_data <- GetModuleFromNodeList(nodes_selected, data_matrix)

        # module data evaluation (for reward)
        predict_prob <- classifier(module_data, data_labels, module_data)[[2]]
        performance_value <- pROC::auc(data_labels, predict_prob, quiet=TRUE)

        # reward
        reward <- RewardValuePerformance(performance_value, length(nodes_selected))

        # update q table
        q_table[state_node, action_node] <- q_table[state_node, action_node] +
                                            alpha_value * (reward + gamma_value * max(q_table[action_node, ]) - q_table[state_node, action_node])

        # episode terminal
        # 1) success: performance_value == 1
        # 2) time out: max size
        if(performance_value == 1 || length(nodes_selected) >= 50){
          # print(paste("-- end at", length(nodes_selected), performance_value))
          break
        }
      }

      utils::setTxtProgressBar(p_bar, t)
    }
    close(p_bar)

    # module determination
    multi_module_list[[k]] <- DefineModuleFromQTable(net_matrix, data_matrix, data_labels, q_table, agent_list[k], classifier)
  }

  return(multi_module_list)
}



#' Epsilon Greedy Strategy
#'
#' @param nodes_selected nodes in current module, vector
#' @param net_matrix adjacency matrix, matrix
#' @param q_table q table, matrix
#' @param epsilon epsilon rate, float
#'
#' @return action node
#' @export
#'
#' @examples "Omit"
EpsilonGreedyModified <- function(nodes_selected, net_matrix, q_table, epsilon)
{
  # action space
  action_space <- GetModuleNeighborNodes(nodes_selected, net_matrix)
  if(length(action_space) == 0){  # if no neighbors
    return(-1)
  }

  # state space
  state_node <- nodes_selected[length(nodes_selected)]

  # action selection
  action <- action_space[1]
  if(length(action_space) > 1)
  {
    if(stats::runif(1, 0, 1) <= epsilon){  # random
      action <- sample(action_space, 1)

    }else{  # greedy, q_table["state", "actions"]
      q_table_values <- q_table[state_node, action_space]
      index_max_values <- which(q_table_values == max(q_table_values))
      action <- ifelse(length(index_max_values) > 1,
                       action_space[sample(index_max_values, 1)],
                       action_space[index_max_values])
    }
  }

  return(action)
}



###########################
##### Agent Selection #####




#' Graph Centrality
#'
#' @param net_matrix network matrix, matrix
#' @param centrality_type centrality type, string, only 'closeness'
#'
#' @return node centrality (vector)
#' @export
#'
#' @examples "Omit"
GraphCentrality <- function(net_matrix, centrality_type)
{
  g <- igraph::graph_from_adjacency_matrix(net_matrix, mode="undirected", weighted=TRUE, diag=FALSE)

  # centrality
  node_centralities <- c()
  if(centrality_type == "closeness"){
    node_centralities <- igraph::closeness(g)

  }

  return(node_centralities)
}



#' Define Agents by P Values and Centrality
#'
#' @param net_matrix adjacency matrix, matrix
#' @param data_matrix data matrix, matrix
#' @param data_labels sample labels, factor
#' @param diff_type diff test type, string, only 'u_test'
#' @param centrality_type type of centrality, string, only 'closeness'
#' @param num_agent agent number, int
#' @param delta_value tuning coefficient, float
#'
#' @return a vector of agent nodes
#' @export
#'
#' @examples "Omit"
AgentSelectionByPvalueCentrality <- function(net_matrix, data_matrix, data_labels, diff_type, centrality_type, num_agent, delta_value)
{
  # basic info
  input_features <- 1:ncol(net_matrix)
  input_features <- input_features[apply(net_matrix, 1, sum) != 0]  # not isolated nodes
  num_features <- length(input_features)

  # p values
  p_values <- rep(1, num_features)
  for(i in 1:num_features)
  {
    feature_data1 <- data_matrix[which(data_labels == levels(data_labels)[1]), input_features[i]]
    feature_data2 <- data_matrix[which(data_labels == levels(data_labels)[2]), input_features[i]]

    if(diff_type == "u_test"){
      p_values[i] <- stats::wilcox.test(feature_data1, feature_data2, exact=FALSE, digits.rank=7)$p.value
    }
  }
  p_values[which(is.na(p_values))] <- 1.0

  # centrality
  node_centralities <- GraphCentrality(net_matrix, centrality_type)

  # comprehensive scores
  com_scores <- delta_value * VectorNormalization(-log(p_values), "max_min") +
                (1-delta_value) * VectorNormalization(node_centralities, "max_min")

  # sort
  sorted_features <- input_features[order(com_scores, decreasing=TRUE)]  # sorted
  selected_agents <- sorted_features[1:num_agent]  # top features

  print(paste("Find", length(selected_agents), "agents"))
  print(selected_agents)

  return(selected_agents)
}



############################
##### Helper Functions #####



#' Get Neighbor Nodes of Module
#'
#' @param nodes_selected nodes in current module, vector
#' @param net_matrix adjacency matrix, matrix
#'
#' @return a vector of neighbor nodes
#' @export
#'
#' @examples "Omit"
GetModuleNeighborNodes <- function(nodes_selected, net_matrix)
{
  neighbor_nodes <- nodes_selected
  for(i in 1:length(nodes_selected)){
    neighbor_nodes <- c(neighbor_nodes, which(net_matrix[nodes_selected[i], ] != 0))
  }
  neighbor_nodes <- setdiff(unique(neighbor_nodes), nodes_selected)  # exclude origin nodes, shouldn't be empty

  return(neighbor_nodes)
}



#' Reward Function
#'
#' Reward considers the module performance and module size simultaneously.
#'
#' @param performance_value current performance, float
#' @param module_size module size, int
#'
#' @return reward value (float)
#' @export
#'
#' @examples "Omit"
RewardValuePerformance <- function(performance_value, module_size)
{
  size_bonus <- 1 + sqrt(1/module_size)  # size bonus

  # Reward: performance * size_bonus
  reward_value <- performance_value * size_bonus

  return(reward_value)
}



#' Define the Final Module
#'
#' Find the module based on the learned q table.
#'
#' @param net_matrix adjacency matrix, matrix
#' @param data_matrix data matrix, matrix
#' @param data_labels sample labels, factor
#' @param q_table q table, matrix
#' @param agent_node agent node, int
#' @param classifier classifier, FUN
#'
#' @return module nodes
#' @export
#'
#' @examples "Omit"
DefineModuleFromQTable <- function(net_matrix, data_matrix, data_labels, q_table, agent_node, classifier)
{
  # basic info
  nodes_selected <- c(agent_node)  # node set
  state_node <- agent_node

  # search
  while(TRUE)
  {
    # max action value
    max_q_value <- max(q_table[state_node, ])

    # terminal: no action
    if(max_q_value == 0){
      print(paste("No action at agent:", agent_node, length(nodes_selected)))
      break
    }

    # take action
    index_max_q_value <- which(q_table[state_node, ] == max_q_value)
    action_node <- ifelse(length(index_max_q_value) > 1,
                          sample(index_max_q_value, 1),
                          index_max_q_value)

    # terminal: dead loop
    if(action_node %in% nodes_selected){
      print(paste("Dead loop at agent:", agent_node, length(nodes_selected)))
      break
    }

    # add the action node
    nodes_selected <- c(nodes_selected, action_node)
    module_data <- GetModuleFromNodeList(nodes_selected, data_matrix)

    # module evaluation
    predict_prob <- classifier(module_data, data_labels, module_data)[[2]]
    module_performance <- pROC::auc(data_labels, predict_prob, quiet=TRUE)

    # terminal: success
    if(module_performance == 1){
      print(paste("Success:", agent_node, length(nodes_selected)))
      break
    }

    # update state
    state_node <- action_node
  }

  # final module
  module_data <- GetModuleFromNodeList(nodes_selected, data_matrix)

  predict_prob <- classifier(module_data, data_labels, module_data)[[2]]
  module_performance <- pROC::auc(data_labels, predict_prob, quiet=TRUE)
  print(paste("module performance,", module_performance))

  return(nodes_selected)
}



#' Module Data
#'
#' @param nodes_selected nodes in current module, vector
#' @param data_matrix training data, matrix
#'
#' @return data of nodes, matrix
#' @export
#'
#' @examples "Omit"
GetModuleFromNodeList <- function(nodes_selected, data_matrix)
{
  # module matrix
  node_data <- matrix(data_matrix[, nodes_selected], ncol=length(nodes_selected))  # order as index

  return(node_data)
}



#' Graph Module Data
#'
#' @param multi_module_list module index list, list of vector
#' @param net_matrix adjacency matrix, matrix
#' @param train_data_matrix training data, matrix
#' @param test_data_matrix test data, matrix
#'
#' @return list of module data (nodes, training data, test data)
#' @export
#'
#' @examples "Omit"
GetModuleDataFromModuleList <- function(multi_module_list, net_matrix, train_data_matrix, test_data_matrix)
{
  # init: module, node data
  list_module_node_data_train <- list()
  list_module_node_data_test <- list()

  # module info
  module_number <- length(multi_module_list)

  for(i in 1:module_number)
  {
    # index of node
    index_module_node <- multi_module_list[[i]]

    # data of node
    list_module_node_data_train[[i]] <- GetModuleFromNodeList(index_module_node, train_data_matrix)  # order as index
    list_module_node_data_test[[i]] <- GetModuleFromNodeList(index_module_node, test_data_matrix)  # order as index
  }

  ResultList <- list(node_index = multi_module_list,
                     node_data_train = list_module_node_data_train,
                     node_data_test = list_module_node_data_test)

  return(ResultList)
}




