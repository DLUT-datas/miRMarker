### Networks ###
# Networks on experimental data
# Networks on databases


## Libraries
suppressMessages(library(igraph))
# suppressMessages(source("R/Functions_miRNA.R"))


###############################
###### General Functions ######



#' Generate Network List
#'
#' @param net_type_list string list, list
#' @param data_train train data, matrix
#' @param data_labels sample labels, factor
#' @param data_features feature, vector
#' @param background_sim_matrix_disease sim matrix based on disease, matrix
#' @param background_features_disease features of background_sim_matrix_disease, vector
#'
#' @return a list of networks
#' @export
#'
#' @examples "Omit"
NetworkList <- function(net_type_list, data_train, data_labels, data_features,
                        background_sim_matrix_disease, background_features_disease)
{
  # net list
  print("-- Network List --")

  net_list <- list()
  for(i in 1:length(net_type_list))
  {
    print(paste(i, "--", net_type_list[i]))

    net_tmp <- matrix()
    if(net_type_list[i] == "ComDiffMinus"){
      net_tmp <- NetworkComDiff(data_train, data_labels, data_features, com_type="minus", diff_type="u_test", is_weight_norm=TRUE)

    }else if(net_type_list[i] == "DiseaseBased"){
      net_tmp <- NetworkFromDatabase(data_features, background_sim_matrix_disease, background_features_disease)

    }

    net_tmp[which(is.na(net_tmp))] <- 0.0
    net_list[[i]] <- net_tmp
  }

  return(net_list)
}


#' Graph Info
#'
#' Print the basic info of a graph.
#'
#' @param net_matrix network adjacency matrix, matrix
#'
#' @return None (Info Printed)
#' @export
#'
#' @examples "Omit"
GraphInfo <- function(net_matrix)
{
  g <- igraph::graph_from_adjacency_matrix(net_matrix, mode="undirected", weighted=TRUE, diag=FALSE)
  print("---------------------------")
  print("Graph Info")
  print(paste("Features:", ncol(net_matrix)))
  print(paste("Nodes:", length(igraph::V(g))))
  print(paste("Edges:", length(igraph::E(g))))
  print(paste("connected:", igraph::is_connected(g)))
  print("---------------------------")
}


#' Calculate the Combined Data
#'
#' @param data_train train data, matrix
#' @param com_type combined type, string, only 'minus'
#'
#' @return a list of results (combined_data, feature_pairs)
#' @export
#'
#' @examples "Omit"
CombinedData <- function(data_train, com_type)
{
  # basic info
  feature_number <- ncol(data_train)
  index_feature <- 1:feature_number

  # index vector
  feature_pairs <- t(utils::combn(index_feature, 2))
  colnames(feature_pairs) <- c('feature1', 'feature2')
  feature1_vector <- feature_pairs[, 1]
  feature2_vector <- feature_pairs[, 2]

  # data pairs
  feature1_data <- data_train[, feature1_vector]
  feature2_data <- data_train[, feature2_vector]

  # combined data
  combined_data <- matrix()
  if(com_type == "minus"){
    combined_data <- feature1_data - feature2_data

  }
  colnames(combined_data) <- paste0('F_', feature1_vector, '_', feature2_vector)

  Results <- list(combined_data, feature_pairs)
  return(Results)
}



#' P values for Combined Differences
#'
#' @param combined_data combined data, matrix
#' @param data_labels sample labels, factor
#' @param diff_type diff type, string, only 'u_test'
#'
#' @return a vector of p values
#' @export
#'
#' @examples "Omit"
CombinedDataPvalues <- function(combined_data, data_labels, diff_type)
{
  # combined data
  # print("combined data p values...")
  pair_number <- ncol(combined_data)

  # class index
  index_class1 <- which(data_labels == levels(data_labels)[1])
  index_class2 <- which(data_labels == levels(data_labels)[2])

  # difference significance
  p_values <- rep(1, pair_number)
  for(i in 1:pair_number){
    pair_data_class1 <- combined_data[index_class1, i]
    pair_data_class2 <- combined_data[index_class2, i]

    if(diff_type == "u_test"){
      p_values[i] <- stats::wilcox.test(pair_data_class1, pair_data_class2, exact=FALSE, digits.rank=7)$p.value
    }
  }

  p_values[which(is.na(p_values))] <- 1.0

  return(p_values)
}


#' Normalize the values in network
#'
#' Min-Max normalization for edge weights in network.
#'
#' @param net_matrix network adjacency matrix, matrix
#'
#' @return normalized network, matrix
#' @export
#'
#' @examples "Omit"
NetworkValueZoom <- function(net_matrix)
{
  net_matrix_copy <- net_matrix

  # upper values
  upper_values <- net_matrix[upper.tri(net_matrix)]  # all upper tri edges
  index_non_zero <- which(upper_values != 0)  # index of nonzero

  # zoom (max-min)
  min_value <- min(upper_values[index_non_zero])  # min value
  max_value <- max(upper_values[index_non_zero])  # max value
  upper_values[index_non_zero] <- (upper_values[index_non_zero] - min_value) / (max_value - min_value)

  net_matrix_copy[upper.tri(net_matrix)] <- upper_values
  net_matrix_copy[lower.tri(net_matrix)] <- t(net_matrix_copy)[lower.tri(net_matrix)]

  return(net_matrix_copy)
}


#################################
###### Networks Thresholds ######



#' Define Network Threshold by Power-Law Fitting
#'
#' @param net_matrix network adjacency matrix, matrix
#' @param threshold_list potential threshold, vector
#'
#' @return best_threshold
#' @export
#'
#' @examples "Omit"
ThresholdByPowerLaw <- function(net_matrix, threshold_list)
{
  # potential
  best_value <- Inf
  best_threshold <- 0.8

  for(i in 1:length(threshold_list))
  {
    tmp_net <- net_matrix
    tmp_net[net_matrix < threshold_list[i]] <- 0.0

    g <- igraph::graph_from_adjacency_matrix(tmp_net, mode="undirected", weighted=TRUE, diag=FALSE)
    fit <- igraph::fit_power_law(igraph::degree(g), xmin=1)  # degree(): "mode" is ignored by "undirected"

    # Smaller stat donates better fit
    if(fit$KS.stat < best_value){
      best_value <- fit$KS.stat
      best_threshold <- threshold_list[i]

      if(fit$KS.stat == 0){
        # print("min KS stat")
        break
      }
    }
  }

  print(paste("PowerLaw:", best_threshold, best_value))
  return(best_threshold)
}



#' Maximum Spanning Tree
#'
#' Maximum spanning tree for a network.
#'
#' @param net_matrix adjacency matrix, matrix
#'
#' @return a MST matrix
#' @export
#'
#' @examples "Omit"
GraphMST <- function(net_matrix)
{
  # reverse the weights
  net_matrix_inverse <- 1/(1 + net_matrix)  # reverse the weights
  diag(net_matrix_inverse) <- 0.0

  # MST
  g <- igraph::graph_from_adjacency_matrix(net_matrix_inverse, mode="undirected", weighted=TRUE, diag=FALSE)
  g_mst <- igraph::mst(g)

  # transfer to matrix
  g_mst_matrix <- as.matrix(igraph::as_adjacency_matrix(g_mst, type="both", attr="weight"))
  index_weights <- which(g_mst_matrix != 0)
  g_mst_matrix[index_weights] <- (1/g_mst_matrix[index_weights]) - 1

  return(g_mst_matrix)
}



#' Maximum Spanning Tree and kNN Graph
#'
#' For edges filter at specific k:
#' 1) MST: MST for connectivity
#' 2) KNN: KNN for more links
#'
#' @param net_matrix adjacency matrix, matrix
#' @param k_value k value in knn, int
#' @param knn_type type, string, only 'any'
#'
#' @return a network matrix
#' @export
#'
#' @examples "Omit"
GraphMSTKNN <- function(net_matrix, k_value, knn_type)
{
  num_features <- ncol(net_matrix)

  # MST Graph
  graph_mst_matrix <- GraphMST(net_matrix)

  # add KNN links
  mask_knn_matrix <- matrix(FALSE, ncol=num_features, nrow=num_features)
  for(i in 1:num_features)
  {
    most_weights_index <- order(net_matrix[i, ], decreasing = TRUE)[1:k_value]  # index (most)
    mask_knn_matrix[i, most_weights_index] <- TRUE
  }

  # knn graph
  mask_knn_matrix_final <- matrix()
  if(knn_type == "any"){
    mask_knn_matrix_final <- mask_knn_matrix | t(mask_knn_matrix)  # any TRUE

  }
  graph_mst_matrix[mask_knn_matrix_final] <- net_matrix[mask_knn_matrix_final]
  diag(graph_mst_matrix) <- 0.0

  return(graph_mst_matrix)
}



#' Maximum Spanning Tree and kNN Graph Graph with param defined
#'
#' For edges filter at specific k
#' 1) MST: MST for connectivity
#' 2) KNN: KNN for more links
#' Determine the best k by PowerLaw fitting.
#'
#' @param net_matrix adjacency matrix, matrix
#' @param k_value_list list of k values
#' @param knn_type type, string, only 'any'
#'
#' @return a network matrix
#' @export
#'
#' @examples "Omit"
GraphMSTKNNDefined <- function(net_matrix, k_value_list, knn_type)
{
  # potential
  best_stats <- Inf
  best_k_value <- 5
  best_net_matrix <- GraphMSTKNN(net_matrix, 5, knn_type)

  for(i in 1:length(k_value_list))
  {
    # mst + knn graph
    tmp_net <- GraphMSTKNN(net_matrix, k_value_list[i], knn_type)

    g <- igraph::graph_from_adjacency_matrix(tmp_net, mode="undirected", weighted=TRUE, diag=FALSE)
    fit <- igraph::fit_power_law(igraph::degree(g), xmin=1)

    if(fit$KS.stat < best_stats){
      best_stats <- fit$KS.stat
      best_k_value <- k_value_list[i]
      best_net_matrix <- tmp_net

      if(fit$KS.stat == 0){
        # print("min KS stat")
        break
      }
    }
  }

  print(paste("PowerLaw:", best_stats, "at", best_k_value))
  return(best_net_matrix)
}



#####################################
###### Networks on Computation ######


#' Network for Combined Difference
#'
#' @param data_train train data, matrix
#' @param data_labels sample labels, factor
#' @param data_features features, vector
#' @param com_type combined type, string, only 'minus'
#' @param diff_type diff type, string, only 'u_test'
#' @param is_weight_norm whether weights are normalized, bool
#'
#' @return a network, matrix
#' @export
#'
#' @examples "Omit"
NetworkComDiff <- function(data_train, data_labels, data_features, com_type="minus", diff_type="u_test", is_weight_norm=TRUE)
{
  # basic data
  feature_number <- ncol(data_train)

  # combined data
  combined_results <- CombinedData(data_train, com_type)
  combined_data <- combined_results[[1]]  # combined data
  pair_number <- ncol(combined_data)  # pair number

  # p values for combined data
  p_values <- CombinedDataPvalues(combined_data, data_labels, diff_type)
  log_p_values <- -log(p_values)
  if(is_weight_norm){
    log_p_values <- VectorNormalization(log_p_values, "max_min")  # may normalize in fusion stage
  }

  # Network (all positive values)
  net <- matrix(0, ncol=feature_number, nrow=feature_number)
  colnames(net) <- data_features
  rownames(net) <- data_features

  net[lower.tri(net, diag=FALSE)] <- log_p_values  # lower tri
  net <- net + t(net)  # copy to upper tri

  return(net)
}


###################################
###### Networks on Databases ######



#' Network based on Knowledge Base
#'
#' @param input_features input features, vector
#' @param background_sim_matrix background sim matrix, matrix
#' @param background_features background features, vector
#'
#' @return a sim matrix
#' @export
#'
#' @examples "Omit"
NetworkFromDatabase <- function(input_features, background_sim_matrix, background_features)
{
  # background extension
  num_background_features <- length(background_features)
  background_sim_matrix_copy <- rbind(cbind(background_sim_matrix, rep(0, num_background_features)), rep(0, num_background_features+1))

  # index of input
  num_input_features <- length(input_features)
  index_input_features <- rep(0, num_input_features)
  for(i in 1:num_input_features){
    index_input_features[i] <- ifelse((input_features[i] %in% background_features),
                                      which(input_features[i] == background_features),  # target column
                                      num_background_features+1)  # blank column
  }

  # target matrix
  sim_matrix <- background_sim_matrix_copy[index_input_features, index_input_features]
  colnames(sim_matrix) <- input_features
  rownames(sim_matrix) <- input_features

  return(sim_matrix)
}



#' Networks on Database Weighted
#'
#' @param str_experi network based on experimental data, string
#' @param beta_value coefficient for integrating, float
#' @param data_train train data, matrix
#' @param data_labels sample labels, factor
#' @param data_features feature, vector
#' @param background_sim_matrix sim matrix based on database, matrix
#' @param background_features features of background_sim_matrix, vector
#'
#' @return a network by weighted integrating
#' @export
#'
#' @examples "Omit"
NetworkExperimentalDatabaseWeighted <- function(str_experi, beta_value, data_train, data_labels, data_features, background_sim_matrix, background_features)
{
  # network based on experimental data
  data_network_matrix <- matrix()
  if(str_experi == "ComDiffMinus"){
    data_network_matrix <- NetworkComDiff(data_train, data_labels, data_features, com_type="minus", diff_type="u_test", is_weight_norm=TRUE)
  }

  # network based on knowledge database
  database_network_matrix <- NetworkFromDatabase(data_features, background_sim_matrix, background_features)

  # weighted
  data_network_matrix <- NetworkValueZoom(data_network_matrix)
  diag(data_network_matrix) <- 0

  database_network_matrix <- NetworkValueZoom(database_network_matrix)
  diag(database_network_matrix) <- 0

  network_weighted <- beta_value * data_network_matrix + (1-beta_value) * database_network_matrix

  return(network_weighted)
}


